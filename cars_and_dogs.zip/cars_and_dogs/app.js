const express = require("express");
const app = express();
// const path = require('path');

app.listen(7077, () => console.log("listening on port 7077"));

// app.use(express.static(path.join(__dirname, 'stylesheets')));
app.use(express.static(__dirname));

app.set('view engine', 'ejs');
app.set('views', __dirname + '/views');

app.get('/', (request, response) => {
    response.render('index');
});

app.get('/cars', (request, response) => {
    response.render('cars');
});

app.get('/dogs', (request, response) => {
    response.render('dogs');
});

app.get('/cars/new', (request, response) => {
    response.render('form');
});

// app.set('stylesheets', __dirname + '/stylesheets');

// app.get('stylesheets/style.css', (request, response) => {
//     response.render('style.css')
// });